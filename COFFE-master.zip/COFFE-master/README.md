COFFE
=====

COFFE is a tool to create the circuitry and area, delay and power models for FPGA tiles (logic, RAM or heterogeneous tiles like DSP blocks).

If you make changes to COFFE, run the "tests_top_level.py" script in the "tests" folder to do some basic checks that existing functionality still works.

How to cite:  
Read the citation guide.
