<?php

use Aprendible\StorageLinkRoute\Http\Controllers\StorageLinkController;

Route::get('storage-link', StorageLinkController::class);
