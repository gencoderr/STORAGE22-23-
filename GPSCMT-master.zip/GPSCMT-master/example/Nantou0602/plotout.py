from gpscmt import view

res_file='GPSCMT_15.000000.res'
model_file='GPSCMT_dhat.dat'
data_file='Coseis_0602.gam'
view.res_map(res_file,model_file,data_file)
