#!/usr/bin/env perl
use strict;
use warnings;
use SOOT qw/:all/;

fillrandom();
$gApplication->Run();

sub fillrandom {
  #Fill a 1-D histogram from a parametric function
  # To see the output of this macro, click begin_html <a href="gif/fillrandom.gif">here</a>. end_html
  #Author: Rene Brun
   
  my $c1 = TCanvas->new("c1","The FillRandom example",200,10,700,900)->keep;
  $c1->SetFillColor(18);

  my $pad1 = TPad->new("pad1","The pad with the function",0.05,0.50,0.95,0.95,21.)->keep;
  my $pad2 = TPad->new("pad2","The pad with the histogram",0.05,0.05,0.95,0.45,21.)->keep;
  $pad1->Draw();
  $pad2->Draw();
  $pad1->cd();

  $gBenchmark->Start("fillrandom");
  #
  # A function (any dimension) or a formula may reference
  # an already defined formula
  #
  my $form1 = TFormula->new("form1","abs(sin(x)/x)")->keep;
  my $sqroot = TF1->new("sqroot","x*gaus(0) + [3]*form1",0,10)->keep;
  $sqroot->SetParameters(10,4,1,20);
  $pad1->SetGridx();
  $pad1->SetGridy();
  $pad1->GetFrame()->SetFillColor(42);
  $pad1->GetFrame()->SetBorderMode(-1);
  $pad1->GetFrame()->SetBorderSize(5);
  $sqroot->SetLineColor(4);
  $sqroot->SetLineWidth(6);
  $sqroot->Draw();
  my $lfunction = TPaveLabel->new(5,39,9.8,46,"The sqroot function")->keep;
  $lfunction->SetFillColor(41);
  $lfunction->Draw();
  $c1->Update();

  #
  # Create a one dimensional histogram (one float per bin)
  # and fill it following the distribution in function sqroot.
  #
  $pad2->cd();
  $pad2->GetFrame()->SetFillColor(42);
  $pad2->GetFrame()->SetBorderMode(-1);
  $pad2->GetFrame()->SetBorderSize(5);
  my $h1f = TH1F->new("h1f","Test random numbers",200,0,10)->keep;
  $h1f->SetFillColor(45);
  $h1f->FillRandom("sqroot",10000);
  $h1f->Draw();
  $c1->Update();
  #
  # Open a ROOT file and save the formula, function and histogram
  #
  my $myfile = TFile->new("fillrandom.root","RECREATE");
  $form1->Write();
  $sqroot->Write();
  $h1f->Write();
  $gBenchmark->Show("fillrandom");
}
