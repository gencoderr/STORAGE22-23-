package ExtUtils::XSpp;

use strict;
use warnings;

use ExtUtils::XSpp::Driver;

our $VERSION = '0.1602';

1;
