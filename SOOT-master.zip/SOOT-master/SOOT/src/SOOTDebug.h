#ifndef _SOOTDebug_h_
#define _SOOTDebug_h_

// #define SOOT_DEBUG 1
#undef SOOT_DEBUG

// #define SOOT_PTRTABLE_DEBUG 1
#undef SOOT_PTRTABLE_DEBUG

#endif
